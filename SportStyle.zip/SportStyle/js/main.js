﻿const products = [
  {
    id: 1,
    category: "camisetas",
    image: "https://images.unsplash.com/photo-1526401485004-8c9e1f84b1b6?auto=format&fit=crop&w=640&q=80",
    name: "Camiseta Fit Pro",
    price: 24.99,
    description: "Máxima libertad de movimiento con tecnología transpirable."
  },
  {
    id: 2,
    category: "camisetas",
    image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=640&q=80",
    name: "Top Athleisure",
    price: 29.99,
    description: "Diseño ligero para gimnasio y entrenamiento diario."
  },
  {
    id: 3,
    category: "pantalones",
    image: "https://images.unsplash.com/photo-1514996937319-344454492b37?auto=format&fit=crop&w=640&q=80",
    name: "Jogger Ultra",
    price: 39.99,
    description: "Ajuste cómodo con tejidos elásticos de secado rápido."
  },
  {
    id: 4,
    category: "pantalones",
    image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=640&q=80",
    name: "Leggings Power",
    price: 34.5,
    description: "Soporte ideal para yoga, ciclismo y running."
  },
  {
    id: 5,
    category: "accesorios",
    image: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=640&q=80",
    name: "Mochila Sport",
    price: 45.0,
    description: "Organizador con compartimentos para todo tu equipo."
  },
  {
    id: 6,
    category: "accesorios",
    image: "https://images.unsplash.com/photo-1495121605193-b116b5b9c5d9?auto=format&fit=crop&w=640&q=80",
    name: "Gorro Performance",
    price: 14.5,
    description: "Protección ligera para entrenar al aire libre."
  },
  {
    id: 7,
    category: "accesorios",
    image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=640&q=80",
    name: "Calcetines Grip",
    price: 12.0,
    description: "Agarre extra para entrenamiento funcional y gimnasio."
  },
  {
    id: 8,
    category: "camisetas",
    image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=640&q=80",
    name: "Camiseta Eco",
    price: 27.9,
    description: "Tejido ecológico pensado para deportistas conscientes."
  }
];

// Clave de almacenamiento para el carrito.
// Actualmente se usa sessionStorage: el carrito se borra cuando se cierra la pestaña.
// Si prefieres persistencia entre sesiones, cambia a localStorage.
const CART_STORAGE = "sportystyle-cart";

// Configuración de Auth0.
// Si no usas Auth0, el login debe eliminarse o esta configuración debe llenarse.
const AUTH0_CONFIG = {
  domain: "dev-s1w1oql8syath8a8.us.auth0.com",
  client_id: "CbbyuKWD7emq23kJcPM8rLdZX886sMyv"
};

let auth0Client = null;
let cart = JSON.parse(sessionStorage.getItem(CART_STORAGE)) || [];
let userProfile = null;

// Referencias a elementos del DOM para uso repetido.
const productList = document.getElementById("product-list");
const cartCount = document.getElementById("cart-count");
const cartDrawer = document.getElementById("cart-drawer");
const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");
const pageCartItems = document.getElementById("page-cart-items");
const pageCartTotal = document.getElementById("page-cart-total");
const openCart = document.getElementById("open-cart");
const closeCart = document.getElementById("close-cart");
const checkoutButton = document.getElementById("checkout-button");
const loginButton = document.getElementById("open-login");
const sessionChip = document.getElementById("session-chip");
const toast = document.getElementById("toast");
const checkoutModal = document.getElementById("checkout-modal");
const closeCheckout = document.getElementById("close-checkout");
const checkoutSummary = document.getElementById("checkout-summary");
const shippingForm = document.getElementById("shipping-form");
const fullNameInput = document.getElementById("full-name");
const addressInput = document.getElementById("shipping-address");
const emailInput = document.getElementById("shipping-email");
const phoneInput = document.getElementById("shipping-phone");
const formError = document.getElementById("form-error");
const checkoutView = document.getElementById("checkout-view");
const confirmationView = document.getElementById("confirmation-view");
const customerName = document.getElementById("customer-name");
const orderDetails = document.getElementById("order-details");
const closeConfirmation = document.getElementById("close-confirmation");
const scrollProducts = document.getElementById("scroll-products");
const guestCheckout = document.getElementById("guest-checkout");
const categoryButtons = document.querySelectorAll(".category-btn");
const welcomeMessage = document.getElementById("welcome-message");

function saveCart() {
  // Guarda el carrito en sessionStorage para que persista mientras dure la pestaña.
  sessionStorage.setItem(CART_STORAGE, JSON.stringify(cart));
}

function formatPrice(value) {
  // Convierte un número decimal a formato de precio con dos decimales.
  return `$${value.toFixed(2)}`;
}

function showToast(message) {
  // Muestra un mensaje breve en pantalla.
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(showToast.timeoutId);
  showToast.timeoutId = setTimeout(() => toast.classList.add("hidden"), 3200);
}

function getProductById(productId) {
  // Busca un producto por su id dentro del catálogo.
  return products.find(product => product.id === productId);
}

function renderUser() {
  // Actualiza el texto de bienvenida y el botón de login/ logout.
  if (userProfile) {
    const name = userProfile.name || userProfile.nickname || userProfile.email;
    welcomeMessage.textContent = `Bienvenido, ${name}`;
    sessionChip.textContent = `Sesión activa: ${name}`;
    loginButton.textContent = "Cerrar sesión";
  } else {
    welcomeMessage.textContent = "";
    sessionChip.textContent = "Sesión invitado";
    loginButton.textContent = "Iniciar sesión";
  }
}

function renderProducts(filter = "all") {
  // Genera la lista de productos según la categoría seleccionada.
  productList.innerHTML = "";
  const visible = products.filter(product => filter === "all" || product.category === filter);

  visible.forEach(product => {
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="product-badge">${product.category}</div>
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <div class="product-price">
        <span>${formatPrice(product.price)}</span>
        <button class="primary-btn" data-action="add" data-id="${product.id}">Agregar al carrito</button>
      </div>
    `;
    productList.appendChild(card);
  });
}

function renderCart() {
  // Renderiza el contenido del carrito en ambos paneles de la página.
  cartItems.innerHTML = "";
  pageCartItems.innerHTML = "";

  if (!cart.length) {
    const emptyMessage = `<p class="empty-cart">Tu carrito está vacío. Añade productos para continuar.</p>`;
    cartItems.innerHTML = emptyMessage;
    pageCartItems.innerHTML = emptyMessage;
    cartTotal.textContent = formatPrice(0);
    pageCartTotal.textContent = formatPrice(0);
    cartCount.textContent = "0";
    return;
  }

  cart.forEach(item => {
    const product = getProductById(item.id);
    if (!product) return;

    const row = document.createElement("div");
    row.className = "cart-item";
    row.innerHTML = `
      <div>
        <h4>${product.name}</h4>
        <small>${formatPrice(product.price)} x ${item.quantity}</small>
      </div>
      <div class="quantity-controls">
        <button data-action="decrease" data-id="${item.id}">-</button>
        <span>${item.quantity}</span>
        <button data-action="increase" data-id="${item.id}">+</button>
      </div>
    `;

    cartItems.appendChild(row);
    pageCartItems.appendChild(row.cloneNode(true));
  });

  const total = cart.reduce((sum, item) => {
    const product = getProductById(item.id);
    return product ? sum + product.price * item.quantity : sum;
  }, 0);

  cartTotal.textContent = formatPrice(total);
  pageCartTotal.textContent = formatPrice(total);
  cartCount.textContent = String(cart.reduce((sum, item) => sum + item.quantity, 0));
}

function addItemToCart(productId) {
  // Añade un producto al carrito o incrementa su cantidad si ya existe.
  const existing = cart.find(item => item.id === productId);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ id: productId, quantity: 1 });
  }

  saveCart();
  renderCart();
  showToast("Producto agregado al carrito.");
}

function updateCartItem(productId, change) {
  // Cambia la cantidad de un producto y elimina si queda con 0 unidades.
  const item = cart.find(item => item.id === productId);
  if (!item) return;

  item.quantity += change;
  if (item.quantity <= 0) {
    cart = cart.filter(row => row.id !== productId);
  }

  saveCart();
  renderCart();
}

function openDrawer(drawer) {
  // Muestra un panel lateral.
  drawer.classList.remove("hidden");
}

function closeDrawer(drawer) {
  // Oculta un panel lateral.
  drawer.classList.add("hidden");
}

function openModal(modal) {
  // Muestra un modal en pantalla.
  modal.classList.remove("hidden");
}

function closeModal(modal) {
  // Oculta un modal.
  modal.classList.add("hidden");
}

async function initAuth() {
  // Inicializa Auth0 si el SDK está cargado y la configuración es válida.
  if (!window.createAuth0Client) {
    showToast("No se pudo cargar Auth0. Verifica la conexión al SDK.");
    return;
  }

  if (!AUTH0_CONFIG.client_id.trim() || !AUTH0_CONFIG.domain.trim()) {
    showToast("Auth0 no está configurado. El login no estará disponible.");
    return;
  }

  auth0Client = await createAuth0Client(AUTH0_CONFIG);
  const isAuthenticated = await auth0Client.isAuthenticated();
  if (isAuthenticated) {
    userProfile = await auth0Client.getUser();
    renderUser();
  }
}

async function handleAuth() {
  // Maneja inicio de sesión con popup o cierre de sesión local.
  if (!auth0Client) {
    showToast("Auth0 no está inicializado todavía.");
    return;
  }

  if (userProfile) {
    auth0Client.logout({ localOnly: true });
    userProfile = null;
    cart = [];
    saveCart();
    renderCart();
    renderUser();
    showToast("Has cerrado sesión.");
    return;
  }

  try {
    await auth0Client.loginWithPopup();
    userProfile = await auth0Client.getUser();
    renderUser();
    showToast(`Bienvenido, ${userProfile.name || userProfile.email}`);
  } catch (error) {
    console.error(error);
    showToast("Error durante el inicio de sesión.");
  }
}

function isValidEmail(value) {
  // Comprueba que el correo tenga un formato básico válido.
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isValidPhone(value) {
  // Comprueba que el teléfono tenga solo dígitos y longitud razonable.
  return /^\d{7,15}$/.test(value);
}

function validateShippingForm() {
  // Valida los campos requeridos del formulario de envío.
  const fullName = fullNameInput.value.trim();
  const address = addressInput.value.trim();
  const email = emailInput.value.trim();
  const phone = phoneInput.value.trim();

  if (!fullName) {
    formError.textContent = "Ingresa tu nombre completo.";
    return false;
  }

  if (!address) {
    formError.textContent = "Ingresa tu dirección de envío.";
    return false;
  }

  if (!isValidEmail(email)) {
    formError.textContent = "Ingresa un correo electrónico válido.";
    return false;
  }

  if (!isValidPhone(phone)) {
    formError.textContent = "Ingresa un teléfono válido con solo números.";
    return false;
  }

  formError.textContent = "";
  return true;
}

function resetCheckoutView() {
  // Vuelve a mostrar el formulario de pago y oculta la confirmación.
  checkoutView.classList.remove("hidden");
  confirmationView.classList.add("hidden");
  formError.textContent = "";
  shippingForm.reset();

  if (userProfile) {
    emailInput.value = userProfile.email || "";
    fullNameInput.value = userProfile.name || userProfile.nickname || "";
  }
}

function fillCheckoutSummary() {
  // Genera el resumen del pedido dentro del modal de pago.
  checkoutSummary.innerHTML = "";

  const subtotal = cart.reduce((sum, item) => {
    const product = getProductById(item.id);
    if (!product) return sum;
    const total = product.price * item.quantity;

    const row = document.createElement("div");
    row.className = "checkout-item";
    row.innerHTML = `<span>${product.name} x ${item.quantity}</span><strong>${formatPrice(total)}</strong>`;
    checkoutSummary.appendChild(row);

    return sum + total;
  }, 0);

  const fees = subtotal * 0.06;
  const total = subtotal + fees;

  const summaryTotal = document.createElement("div");
  summaryTotal.className = "checkout-item";
  summaryTotal.innerHTML = `<span>Envío y manejo</span><strong>${formatPrice(fees)}</strong>`;

  const finalTotal = document.createElement("div");
  finalTotal.className = "checkout-item";
  finalTotal.innerHTML = `<span>Total a pagar</span><strong>${formatPrice(total)}</strong>`;

  checkoutSummary.appendChild(summaryTotal);
  checkoutSummary.appendChild(finalTotal);
}

function openCheckout() {
  // Abre el modal de checkout solo si hay artículos en el carrito.
  if (!cart.length) {
    showToast("Añade productos antes de comprar.");
    return;
  }

  resetCheckoutView();
  fillCheckoutSummary();
  openModal(checkoutModal);
}

function showConfirmation(data) {
  // Muestra la pantalla de confirmación luego de procesar el pedido.
  const items = cart
    .map(item => {
      const product = getProductById(item.id);
      return product ? { name: product.name, quantity: item.quantity, price: product.price } : null;
    })
    .filter(Boolean);

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const fees = subtotal * 0.06;
  const total = subtotal + fees;

  orderDetails.innerHTML = "";

  items.forEach(item => {
    const row = document.createElement("div");
    row.className = "checkout-item";
    row.innerHTML = `<span>${item.name} x ${item.quantity}</span><strong>${formatPrice(item.price * item.quantity)}</strong>`;
    orderDetails.appendChild(row);
  });

  const feeRow = document.createElement("div");
  feeRow.className = "checkout-item";
  feeRow.innerHTML = `<span>Envío y manejo</span><strong>${formatPrice(fees)}</strong>`;

  const totalRow = document.createElement("div");
  totalRow.className = "checkout-item";
  totalRow.innerHTML = `<span>Total</span><strong>${formatPrice(total)}</strong>`;

  orderDetails.appendChild(feeRow);
  orderDetails.appendChild(totalRow);

  customerName.textContent = data.fullName;
  checkoutView.classList.add("hidden");
  confirmationView.classList.remove("hidden");
}

function confirmPurchase(data) {
  // Vacía el carrito y muestra la confirmación.
  cart = [];
  saveCart();
  renderCart();
  showConfirmation(data);
}

function handleShippingSubmit(event) {
  // Captura el evento de envío del formulario de pago.
  event.preventDefault();

  if (!cart.length) {
    showToast("No hay productos en el carrito.");
    closeModal(checkoutModal);
    return;
  }

  if (!validateShippingForm()) {
    return;
  }

  const formData = {
    fullName: fullNameInput.value.trim(),
    address: addressInput.value.trim(),
    email: emailInput.value.trim(),
    phone: phoneInput.value.trim()
  };

  confirmPurchase(formData);
}

function init() {
  // Inicia la app: renderiza productos, carrito y configura eventos.
  renderProducts();
  renderCart();
  initAuth();

  window.addEventListener("click", event => {
    const action = event.target.dataset.action;
    const id = Number(event.target.dataset.id);
    if (action === "add") {
      addItemToCart(id);
    }
    if (action === "decrease") {
      updateCartItem(id, -1);
    }
    if (action === "increase") {
      updateCartItem(id, 1);
    }
  });

  openCart.addEventListener("click", () => openDrawer(cartDrawer));
  closeCart.addEventListener("click", () => closeDrawer(cartDrawer));
  checkoutButton.addEventListener("click", openCheckout);
  loginButton.addEventListener("click", handleAuth);
  closeCheckout.addEventListener("click", () => closeModal(checkoutModal));
  closeConfirmation.addEventListener("click", () => closeModal(checkoutModal));
  shippingForm.addEventListener("submit", handleShippingSubmit);
  scrollProducts.addEventListener("click", () => {
    document.getElementById("products-section").scrollIntoView({ behavior: "smooth" });
  });
  guestCheckout.addEventListener("click", openCheckout);

  categoryButtons.forEach(button => {
    button.addEventListener("click", () => {
      categoryButtons.forEach(btn => btn.classList.remove("active"));
      button.classList.add("active");
      renderProducts(button.dataset.category);
    });
  });

  checkoutModal.addEventListener("click", event => {
    if (event.target === checkoutModal) {
      closeModal(checkoutModal);
    }
  });
}

init();
