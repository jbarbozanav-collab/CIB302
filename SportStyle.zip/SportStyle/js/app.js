﻿// Archivo js/app.js
// Actualmente este archivo está vacío y no se incluye en index.html.
// Si no vas a usarlo, puedes eliminarlo para mantener el proyecto limpio.
